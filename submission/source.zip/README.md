# Security Analysis of an IP Camera

Both source code files require the sockets and scapy python libraries and must be run as root to execute.

The programs require .pcap files as input. These files have not been included in the submission as they are specific to the camera being tested and the user account under which testing was performed. Given a different camera, the files can be obtained by capturing in Wireshark under the correct network structure whilst opening the app, and performing the desired actions. Then the correct TCP stream needs to be identified, and only the relevant packets selected. The specified packets can then be saved as a .pcap file for use in the attacking scripts.

To execute the server authentication attack and the same network command execution attack, the connection.py file is used, with captures of the communication we wish to emulate.    
For the different networks command execution attack, the extractandconnect.py file is used, and two captures are required. These are the capture authenticating with the authentication server and requesting the token and location of the camera, and the capture of the camera connecting to and sending a command to the connection server. The token being searched for for replacement in the second capture must be changed to match the specific capture being used as input. 


